﻿using SmartPKB.Models;
using SmartPKB.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using SmartPKB.API;
using Refit;
using Android.Widget;

namespace SmartPKB.Views
{
    public partial class AirCDetailPage : ContentPage
    {
        public AirCDetailPage()
        {
            InitializeComponent();
            BindingContext = this;
            //при инициализации страницы отключаем уведомление о сохранении и отключаем функцию, чтобы не нагружать базу данных
            switcher.Toggled -= switcher_Toggled;
            //добавляем к значению температуры градусы Цельсия
            airTemp.Text = stepper.Value + "°C";
        }

        //переопределяем поведение страницы при её появлении на экране
        protected override void OnAppearing()
        {
            //возвращаем возможность уведомлять 
            switcher.Toggled += switcher_Toggled;
            //применяем переопределённую логику
            base.OnAppearing();
        }

        //переопределяем поведение страницы при её исчезновении с экрана
        protected override async void OnDisappearing()
        {
            IRegLogAPI regLogAPI = RestService.For<IRegLogAPI>("http://10.0.2.2:5000/");
            //создаём объект, которому приравниваем привязанные значения страницы согласно модели AirConditioning
            var air = (AirConditioning)BindingContext;
            //проверяем (на всякий случай) что мы не изменяем пустой объект
            if (!String.IsNullOrEmpty(air.Name))
            {
                //асинхронно сохраняем изменения (подразумевается, что приложением будет пользоваться несколько человек)
                var result = await regLogAPI.UpdateAirConditioning(air);
                //показываем ответ от сервера
                Toast.MakeText(Android.App.Application.Context, result.ToString(), ToastLength.Short).Show();
            }
            //применяем переопределённую логику
            base.OnDisappearing();
        }

        private async void switcher_Toggled(object sender, ToggledEventArgs e)
        {
            IRegLogAPI regLogAPI = RestService.For<IRegLogAPI>("http://10.0.2.2:5000/");
            //если переключатель меняет своё положение
            if (switcher.IsToggled || !switcher.IsToggled)
            {
                //создаём объект, которому приравниваем привязанные значения страницы согласно модели AirConditioning
                var air = (AirConditioning)BindingContext;
                //проверяем (на всякий случай) что мы не изменяем пустой объект
                if (!String.IsNullOrEmpty(air.Name))
                {
                    //асинхронно сохраняем изменения (подразумевается, что приложением будет пользоваться несколько человек)
                    var result = await regLogAPI.UpdateAirConditioning(air);
                    //показываем ответ от сервера
                    Toast.MakeText(Android.App.Application.Context, result.ToString(), ToastLength.Short).Show();
                }
            }
        }

        private async void stepper_ValueChanged(object sender, ValueChangedEventArgs e)
        {
            IRegLogAPI regLogAPI = RestService.For<IRegLogAPI>("http://10.0.2.2:5000/");
            airTemp.Text = Convert.ToInt32(stepper.Value) + "°C";
            var air = (AirConditioning)BindingContext;
            if (!String.IsNullOrEmpty(air.Name))
            {
                var result = await regLogAPI.UpdateAirConditioning(air);
                Toast.MakeText(Android.App.Application.Context, result.ToString(), ToastLength.Short).Show();
            }
        }

        private void switcher_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            //если переключатель в состоянии "выкл"
            if (switcher.IsToggled == false)
            {
                //отключаем кнопки смены температуры
                stepper.IsEnabled = false;
                //цвет значения температуры делаем серым
                airTemp.TextColor = Color.Gray;
                //цвет подписи делаем серым
                capt.TextColor = Color.Gray;
                //делаем серой картинку
                airPicture.Opacity = 0.5;
            }
            //иначе
            else
            {
                //включаем кнопки
                stepper.IsEnabled = true;
                //цвет значения температуры делаем чёрным
                airTemp.TextColor = Color.Black;
                //цвет подписи делаем черным
                capt.TextColor = Color.Black;
                //делаем чёрной картинку
                airPicture.Opacity = 1;
            }
        }
    }
}
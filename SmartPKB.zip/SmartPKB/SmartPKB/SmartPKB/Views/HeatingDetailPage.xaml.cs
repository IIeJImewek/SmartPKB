﻿using SmartPKB.Models;
using SmartPKB.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using SmartPKB.API;
using Refit;
using Android.Widget;

namespace SmartPKB.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class HeatingDetailPage : ContentPage
    {
        public bool Mode = false;
        public HeatingDetailPage()
        {
            InitializeComponent();
            BindingContext = this;
            toggleSwitcher.Toggled -= toggleSwitcher_Toggled;
            modeSwitcher.Toggled -= modeSwitcher_Toggled;
        }

        //переопределяем поведение страницы при её появлении на экране
        protected override void OnAppearing()
        {
            //возвращаем возможность уведомлять 
            toggleSwitcher.Toggled += toggleSwitcher_Toggled;
            modeSwitcher.Toggled += modeSwitcher_Toggled;
            //применяем переопределённую логику
            base.OnAppearing();
        }

        //определяем режим работы кондиционера
        public void SwitchMode()
        {
            var heating = (Heating)BindingContext;
            if (heating.CurOutput == heating.MaxOutput)
                Mode = false;
            else
                Mode = true;
        }

        private void toggleSwitcher_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            //если переключатель в состоянии "выкл"
            if (toggleSwitcher.IsToggled == false)
            {
                //отключаем кнопки смены температуры
                stepper.IsEnabled = false;
                //цвет значения температуры делаем серым
                heatingTemp.TextColor = Color.Gray;
                //цвет подписи делаем серым
                capt.TextColor = Color.Gray;
                //делаем серой картинку
                heatingPicture.Opacity = 0.5;
                //блокируем возможность переключать режимы работы
                modeSwitcher.IsEnabled = false;
            }
            //иначе
            else
            {
                //включаем кнопки
                stepper.IsEnabled = true;
                //цвет значения температуры делаем чёрным
                heatingTemp.TextColor = Color.Black;
                //цвет подписи делаем черным
                capt.TextColor = Color.Black;
                //делаем чёрной картинку
                heatingPicture.Opacity = 1;
                //делаем доступной возможность переключать режимы работы
                modeSwitcher.IsEnabled = true;
            }
        }

        private async void toggleSwitcher_Toggled(object sender, ToggledEventArgs e)
        {
            IRegLogAPI regLogAPI = RestService.For<IRegLogAPI>("http://10.0.2.2:5000/");
            //если переключатель меняет своё положение
            if (toggleSwitcher.IsToggled || !toggleSwitcher.IsToggled)
            {
                //создаём объект, которому приравниваем привязанные значения страницы согласно модели AirConditioning
                var heating = (Heating)BindingContext;
                //проверяем (на всякий случай) что мы не изменяем пустой объект
                if (!String.IsNullOrEmpty(heating.Name))
                {
                    //асинхронно сохраняем изменения (подразумевается, что приложением будет пользоваться несколько человек)
                    var result = await regLogAPI.UpdateHeating(heating);
                    //показываем ответ от сервера
                    Toast.MakeText(Android.App.Application.Context, result.ToString(), ToastLength.Short).Show();
                }
            }
        }

        private async void modeSwitcher_Toggled(object sender, ToggledEventArgs e)
        {
            IRegLogAPI regLogAPI = RestService.For<IRegLogAPI>("http://10.0.2.2:5000/");
            //если переключатель меняет своё положение
            if (toggleSwitcher.IsToggled || !toggleSwitcher.IsToggled)
            {
                //создаём объект, которому приравниваем привязанные значения страницы согласно модели AirConditioning
                var heating = (Heating)BindingContext;
                if (modeSwitcher.IsToggled == false)
                    heating.CurOutput = heating.NormOutput;
                else if (modeSwitcher.IsToggled == true)
                    heating.CurOutput = heating.MaxOutput;
                //проверяем (на всякий случай) что мы не изменяем пустой объект
                if (!String.IsNullOrEmpty(heating.Name))
                {
                    //асинхронно сохраняем изменения (подразумевается, что приложением будет пользоваться несколько человек)
                    var result = await regLogAPI.UpdateHeating(heating);
                    //показываем ответ от сервера
                    Toast.MakeText(Android.App.Application.Context, result.ToString(), ToastLength.Short).Show();
                }
            }
        }

        private async void stepper_ValueChanged(object sender, ValueChangedEventArgs e)
        {
            IRegLogAPI regLogAPI = RestService.For<IRegLogAPI>("http://10.0.2.2:5000/");
            heatingTemp.Text = Convert.ToInt32(stepper.Value) + "°C";
            var heating = (Heating)BindingContext;
            if (!String.IsNullOrEmpty(heating.Name))
            {
                var result = await regLogAPI.UpdateHeating(heating);
                Toast.MakeText(Android.App.Application.Context, result.ToString(), ToastLength.Short).Show();
            }
        }
    }
}
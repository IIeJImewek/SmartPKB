﻿using SmartPKB.ViewModels;
using System.ComponentModel;
using Xamarin.Forms;

namespace SmartPKB.Views
{
    public partial class ItemDetailPage : ContentPage
    {
        public ItemDetailPage()
        {
            InitializeComponent();
            BindingContext = new ItemDetailViewModel();
        }
    }
}
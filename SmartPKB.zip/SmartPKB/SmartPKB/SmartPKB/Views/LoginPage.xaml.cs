﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Xamarin.Essentials;

using SmartPKB.Models;
using SmartPKB.API;

using Android.Widget;

using Refit;

namespace SmartPKB.Views
{
    public partial class LoginPage : ContentPage
    {
        public LoginPage()
        {
            BindingContext = this;
            InitializeComponent();
        }

        private async void login_Clicked(object sender, EventArgs e)
        {
            if (App.CheckConnection() == true)
            {
                try
                {
                    IRegLogAPI regLogAPI = RestService.For<IRegLogAPI>("http://10.0.2.2:5000/");
                    User user = new User();
                    user.Username = log.Text;
                    user.Password = pass.Text;

                    var result = await regLogAPI.LoginUser(user);

                if (result.Contains("Salt"))
                {
                    await Shell.Current.GoToAsync("//AboutPage");
                    Toast.MakeText(Android.App.Application.Context, "Авторизация успешна", ToastLength.Short).Show();
                }
                else
                {
                    Toast.MakeText(Android.App.Application.Context, result.ToString(), ToastLength.Short).Show();
                }
                }
                catch
                {
                    Toast.MakeText(Android.App.Application.Context, "Ошибка подключения к серверу", ToastLength.Short).Show();
                }
            }
        }
    }
}
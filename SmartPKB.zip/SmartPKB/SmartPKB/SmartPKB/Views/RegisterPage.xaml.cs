﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

using SmartPKB.Models;
using SmartPKB.API;

using Android.Widget;

using Refit;

namespace SmartPKB.Views
{
    public partial class RegisterPage : ContentPage
    {
        public RegisterPage()
        {
            InitializeComponent();
        }

        private async void register_Clicked(object sender, EventArgs e)
        {
            if (App.CheckConnection() == true)
            {
                try
                {
                    if (pass.Text == pass_repeat.Text && (log.Text!=null && pass.Text!=null && pass_repeat.Text!=null))
                    {
                        IRegLogAPI regLogAPI = RestService.For<IRegLogAPI>("http://10.0.2.2:5000/");
                        User user = new User();
                        user.Username = log.Text;
                        user.Password = pass.Text;

                        var result = await regLogAPI.RegisterUser(user);

                        if (result.Contains("успешно"))
                        {
                            await Shell.Current.GoToAsync("//Start/LoginPage");
                            Toast.MakeText(Android.App.Application.Context, result.ToString(), ToastLength.Short).Show();
                        }
                        else
                        {
                            Toast.MakeText(Android.App.Application.Context, result.ToString(), ToastLength.Short).Show();
                        }
                    }
                    else if (log.Text.Length < 4)
                    {
                        Toast.MakeText(Android.App.Application.Context, "Имя пользователя слишком короткое", ToastLength.Short).Show();
                    }
                    else if (pass.Text!=pass_repeat.Text)
                    {
                        Toast.MakeText(Android.App.Application.Context, "Пароли не совпадают", ToastLength.Short).Show();
                    }
                }
                catch
                {
                    Toast.MakeText(Android.App.Application.Context, "Ошибка подключения к серверу или введенные данные некорректны", ToastLength.Short).Show();
                }
            }
        }
    }
}
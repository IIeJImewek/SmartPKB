﻿using SmartPKB.Models;
using SmartPKB.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Xamarin.Essentials;
using Android.Widget;
using SmartPKB.API;
using Refit;

namespace SmartPKB.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AboutPage : ContentPage
    {
        public AboutPage()
        {
            InitializeComponent();
            //при каждой инициализации перезаписываем комнаты заново (во избежание ошибок)
            picker.ItemsSource = null;
            picker.SelectedIndex = -1;
            GetRooms();
            //отключаем кнопку продолжения при первой инициализации
            proceed.IsEnabled = false;
        }

        //переопределяем поведение страницы при её появлении на экране
        protected override async void OnAppearing()
        {
            base.OnAppearing();
        }

        //функция для получения комнат
        protected async void GetRooms()
        {
            IRegLogAPI regLogAPI = RestService.For<IRegLogAPI>("http://10.0.2.2:5000/");
            //асинхронно привязываем данные из таблицы к выпадающему списку
            picker.ItemsSource = await regLogAPI.GetRooms();
        }

        //функция на поведение при изменении выбранного элемента
        void picker_SelectedIndexChanged(object sender, EventArgs e)
        {
            //записываем в объявленное текстовое поле с именем 'header' название выбранной комнаты
            header.Text = "Вы выбрали: " + picker.Items[picker.SelectedIndex];
            //если выбран какой-то элемент
            if (picker.ItemDisplayBinding.ToString() != "" && picker.SelectedIndex != -1)
            {
                //записываем номер выбранной комнаты в глобальную переменную
                App.LocalTemp.Room = picker.SelectedIndex;
                //включаем кнопку "Далее"
                proceed.IsEnabled = true;
            }
        }

        //функция определяющая поведение кнопки "Далее"
        private async void proceed_Clicked(object sender, EventArgs e)
        {
            if (App.CheckConnection() == true)
                //переходим на страничку с Освещением
                await Shell.Current.GoToAsync($"//LightningsPage");   
        }
    }
}
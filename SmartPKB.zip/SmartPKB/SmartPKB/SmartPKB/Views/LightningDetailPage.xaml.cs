﻿using SmartPKB.Models;
using SmartPKB.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using SmartPKB.API;
using Refit;
using Android.Widget;

namespace SmartPKB.Views
{
    public partial class LightningDetailPage : ContentPage
    {
        public LightningDetailPage()
        {
            InitializeComponent();
            BindingContext = this;
            //при инициализации страницы отключаем уведомление о сохранении и отключаем функцию, чтобы не нагружать базу данных
            lightSwitcher.Toggled -= lightSwitcher_Toggled;
            //добавляем к значению яркости процент
            lightValue.Text = lightSlider.Value + "%";
        }

        //переопределяем поведение страницы при её появлении на экране
        protected override void OnAppearing()
        {
            //возвращаем возможность уведомлять 
            lightSwitcher.Toggled += lightSwitcher_Toggled;
            //применяем переопределённую логику
            base.OnAppearing();
        }

        //переопределяем поведение страницы при её исчезновении с экрана
        protected override async void OnDisappearing()
        {
            IRegLogAPI regLogAPI = RestService.For<IRegLogAPI>("http://10.0.2.2:5000/");
            //создаём объект, которому приравниваем привязанные значения страницы согласно модели Lightning
            var lightning = (Lightning)BindingContext;
            //проверяем (на всякий случай) что мы не изменяем пустой объект
            if (!String.IsNullOrEmpty(lightning.Name))
            {
                //асинхронно сохраняем изменения (подразумевается, что приложением будет пользоваться несколько человек)
                var result = await regLogAPI.UpdateLight(lightning);
                //уведомляем о сохранении изменений
                Toast.MakeText(Android.App.Application.Context, result.ToString(), ToastLength.Short).Show();
            }
            //применяем переопределённую логику
            base.OnDisappearing();
        }

        //функция отвечающая за поведение при изменении значения уровня яркости
        private async void Slider_ValueChanged(object sender, ValueChangedEventArgs e)
        {
            IRegLogAPI regLogAPI = RestService.For<IRegLogAPI>("http://10.0.2.2:5000/");
            lightValue.Text = Convert.ToInt32(lightSlider.Value) + "%";
            var lightning = (Lightning)BindingContext;
            if (!String.IsNullOrEmpty(lightning.Name))
            {
                var result = await regLogAPI.UpdateLight(lightning);
            }
        }

        //функция ответственнаая за поведение переключателя при смене него параметров
        private async void Switch_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            //если переключатель в состоянии "выкл"
            if (lightSwitcher.IsToggled == false)
            {
                //отключаем ползунок смены яркости
                lightSlider.IsEnabled = false;
                //цвет подписи уровня яркости делаем серым
                lightValue.TextColor = Color.Gray;
                //делаем серой картинку
                lightPicture.Opacity = 0.5;
            }
            //иначе
            else
            {
                //включаем ползунок
                lightSlider.IsEnabled = true;
                //цвет подписи уровня яркости делаем чёрным
                lightValue.TextColor = Color.Black;
                //делаем чёрной картинку
                lightPicture.Opacity = 1;
            }
        }

        //функция определяющая поведение при нажатии на переключатель
        private async void lightSwitcher_Toggled(object sender, ToggledEventArgs e)
        {
            IRegLogAPI regLogAPI = RestService.For<IRegLogAPI>("http://10.0.2.2:5000/");
            //если переключатель меняет своё положение
            if (lightSwitcher.IsToggled || !lightSwitcher.IsToggled)
            {
                //создаём объект, которому приравниваем привязанные значения страницы согласно модели Lightning
                var lightning = (Lightning)BindingContext;
                //проверяем (на всякий случай) что мы не изменяем пустой объект
                if (!String.IsNullOrEmpty(lightning.Name))
                {
                    //асинхронно сохраняем изменения (подразумевается, что приложением будет пользоваться несколько человек)
                    var result = await regLogAPI.UpdateLight(lightning);
                    //уведомляем о сохранении изменений
                    Toast.MakeText(Android.App.Application.Context, result.ToString(), ToastLength.Short).Show();
                }
            }
        }
    }
}
﻿using SmartPKB.Models;
using SmartPKB.Views;
using SmartPKB.API;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

using Refit;

namespace SmartPKB.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class HeatingPage : ContentPage
    {
        public HeatingPage()
        {
            InitializeComponent();
            Title = "Теплоснабжение";
        }

        //переопределяем поведение страницы при её отображении
        protected override async void OnAppearing()
        {
            IRegLogAPI regLogAPI = RestService.For<IRegLogAPI>("http://10.0.2.2:5000/");

            //привязываем данные из таблицы к странице
            List<Heating> heatings = await regLogAPI.GetHeatings();

            //выбираем для отображения только те устройства, которые соответствуют комнате
            heatingList.ItemsSource = heatings.Where(x => x.Nroom == App.LocalTemp.Room);

            //вызываем переопределённый метод
            base.OnAppearing();
        }

        //обработка нажатия на элемент в списке
        private async void heatingList_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            //создаём объект, который выбрали и который будет структурирован согласно модели 
            Heating selectedHeating = (Heating)e.SelectedItem;
            //создаём новый экземпляр стрницы согласно структуре страницы по редактированию настроек кондиционера
            HeatingDetailPage heatingDetailPage = new HeatingDetailPage
            {
                //в качестве контента для привязки к странице устанавливаем данные из объекта selectedAir
                BindingContext = selectedHeating
            };
            //открываем страницу
            await Navigation.PushAsync(heatingDetailPage);
        }
    }
}
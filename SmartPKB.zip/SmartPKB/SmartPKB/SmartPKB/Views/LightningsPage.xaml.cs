﻿using SmartPKB.Models;
using SmartPKB.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using SmartPKB.API;
using Refit;


namespace SmartPKB.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class LightningsPage : ContentPage
    {
        public LightningsPage()
        {
            InitializeComponent();
            Title = "Освещение";
        }

        //переопределяем поведение страницы при её отображении
        protected override async void OnAppearing()
        {
            IRegLogAPI regLogAPI = RestService.For<IRegLogAPI>("http://10.0.2.2:5000/");
            //создаём таблицу, если её нет
            //await App.Database.CreateLightningTable();

            //привязываем данные из таблицы к странице
            List<Lightning> lights = await regLogAPI.GetLightnings();

            //выбираем для отображения только те устройства, которые соответствуют комнате
            lightningList.ItemsSource = lights.Where(x => x.Nroom == App.LocalTemp.Room);

            //вызываем переопределённый метод
            base.OnAppearing();
        }

        //обработка нажатия на элемент в списке
        private async void lightningList_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            //создаём объект, который выбрали и который будет структурирован согласно модели 
            Lightning selectedLightning = (Lightning)e.SelectedItem;
            //создаём новый экземпляр стрницы согласно структуре страницы по редактированию света
            LightningDetailPage lightningDetailPage = new LightningDetailPage
            {
                //в качестве контента для привязки к странице устанавливаем данные из объекта selectedLightning
                BindingContext = selectedLightning
            };
            //открываем страницу
            await Navigation.PushAsync(lightningDetailPage);
        }
    }
}
﻿using SmartPKB.Views;
using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace SmartPKB
{
    public partial class AppShell : Xamarin.Forms.Shell
    {
        public AppShell()
        {
            InitializeComponent();
            //регистрируем маршруты для перенаправления на страницу по изменению параметров устройств
            Routing.RegisterRoute(nameof(LoginPage), typeof(LoginPage));
            Routing.RegisterRoute(nameof(RegisterPage), typeof(RegisterPage));
            Routing.RegisterRoute(nameof(LightningDetailPage), typeof(LightningDetailPage));
            Routing.RegisterRoute(nameof(AirCDetailPage), typeof(AirCDetailPage));
        }

        //функция возвращения на стартовую страницу по нажатию на вкладку меню "Сменить комнату"
        private async void OnMenuItemClicked(object sender, EventArgs e)
        {
            //переходим на стартовую страницу
            await Shell.Current.GoToAsync("//Start/LoginPage");
        }
    }
}

﻿using SmartPKB.Views;
using System;
using System.IO;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Reflection;
using Xamarin.Essentials;
using Android.Widget;
using System.Linq;

namespace SmartPKB
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            //создаём оболочку приложения
            MainPage = new AppShell();
            Preferences.Set("EndPoint", "http://10.0.2.2:5000/");
        }

        //переопределяем поведение при запуске приложения
        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }

        public static bool CheckConnection()
        {
            var network = Connectivity.NetworkAccess;
            var connType = Connectivity.ConnectionProfiles;
            if (network == NetworkAccess.Internet /*&& connType.Contains(ConnectionProfile.WiFi)*/)
            {
                return true;
            }
            else
            {
                Toast.MakeText(Android.App.Application.Context, "Отсутствует подключение к серверу или к интернету", ToastLength.Short).Show();
                return false;
            }
        }

        //класс ответственный за хранение глобальных временных переменных
        public partial class LocalTemp
        {
            //переменная с выбранной комнатой
            public static int Room = 0;
        }
    }
}

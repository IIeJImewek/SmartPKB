﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

using SmartPKB.Models;
using Refit;

namespace SmartPKB.API
{
    interface IRegLogAPI
    {
        /* http://localhost:5000/api/login */
        [Post("/api/registration")]
        Task<string> RegisterUser([Body] User user);

        [Post("/api/login")]
        Task<string> LoginUser([Body] User user);



        [Get("/api/rooms")]
        Task<List<Room>> GetRooms();



        [Get("/api/lightning")]
        Task<List<Lightning>> GetLightnings();

        [Put("/api/lightning")]
        Task<string> UpdateLight([Body] Lightning lightning);


        [Get("/api/airconditioning")]
        Task<List<AirConditioning>> GetAirConditionings();

        [Put("/api/airconditioning")]
        Task<string> UpdateAirConditioning([Body] AirConditioning air);

        [Get("/api/heating")]
        Task<List<Heating>> GetHeatings();
        [Put("/api/heating")]
        Task<string> UpdateHeating([Body] Heating heating);
    }
}
